package modelo;

public class Ezkutua extends Arma{
	private int bizitza;
	
	public Ezkutua(int pKop, int pPrezioa){
		super(pKop,pPrezioa);
		this.bizitza = 100;
	}
	

}
