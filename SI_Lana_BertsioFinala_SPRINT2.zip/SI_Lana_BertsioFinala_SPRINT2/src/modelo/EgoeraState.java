package modelo;

public interface EgoeraState {
	public void klik(Ontzia pOntzi, Arma pArma);
}
