package modelo;

public enum Egoera {
	URA, ONTZIA, JOTA, OKUPATUTA, URPERATUTA
}
	