package modelo;

public class Bonba extends Arma{
	private int eragina;
	
	public Bonba(int pKop, int pPrezioa) {
		super(pKop,pPrezioa);
		this.eragina = 50;
	}

	
}
