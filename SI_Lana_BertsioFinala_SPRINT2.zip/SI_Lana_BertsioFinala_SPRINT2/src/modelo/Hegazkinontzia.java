package modelo;

public class Hegazkinontzia extends Ontzia {
	public Hegazkinontzia() {
		super();
		tamaina = 4;
	}
}
