package modelo;

public class Urperatuta implements EgoeraState {

	@Override
	public void klik(Ontzia pOntzi, Arma pArma) {
		if (pA)
		
	}
	
}
