package modelo;

public class Misila extends Arma {
	private int eragina;
	
	public Misila(int pKop, int pPrezioa) {
		super(pKop,pPrezioa);
		this.eragina = 100;
	}
	
}
