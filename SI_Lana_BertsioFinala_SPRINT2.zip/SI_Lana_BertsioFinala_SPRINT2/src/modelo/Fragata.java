package modelo;

public class Fragata extends Ontzia {
	public Fragata() {
		super();
		tamaina = 1;
	}
}
