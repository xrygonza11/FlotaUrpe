package modelo;

public class Itsaspekoa extends Ontzia {
	public Itsaspekoa() {
		super();
		tamaina = 3;
	}
}
