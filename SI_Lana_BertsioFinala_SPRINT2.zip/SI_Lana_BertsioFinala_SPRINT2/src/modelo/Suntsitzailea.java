package modelo;

public class Suntsitzailea extends Ontzia {
	public Suntsitzailea() {
		super();
		tamaina = 2;
	}
}
