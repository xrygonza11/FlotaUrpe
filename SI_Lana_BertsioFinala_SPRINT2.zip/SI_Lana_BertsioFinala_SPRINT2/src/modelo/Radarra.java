package modelo;

public class Radarra extends Arma {

	
	public Radarra(int pKop, int pPrezioa) {
		super(pKop,pPrezioa);
	}
	
}
