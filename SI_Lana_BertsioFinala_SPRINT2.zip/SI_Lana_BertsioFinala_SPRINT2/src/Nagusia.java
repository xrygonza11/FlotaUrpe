import vista.Jokoa;

public class Nagusia {
	
	public static void main(String[] args) {
		Jokoa.main(null);
	}
}
